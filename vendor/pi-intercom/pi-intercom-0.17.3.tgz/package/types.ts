export const EXTENSION_BUS_FEATURE = "extension-bus-v1";
export const EXACT_SEND_FEATURE = "exact-send-v1";
export const OFFLINE_DELIVERY_REJECT_FEATURE = "offline-delivery-reject-v1";
/** Broker refused a register because another live process holds the session id. */
export const SESSION_HELD_ERROR_CODE = "E_SESSION_HELD";
export const OFFLINE_REJECT_STATE_CONFLICT_ERROR_CODE = "E_OFFLINE_REJECT_STATE_CONFLICT";
export const TARGET_OFFLINE_NONQUEUEABLE_ERROR_CODE = "E_TARGET_OFFLINE_NONQUEUEABLE";

export type DeliveryState = "socket_delivered" | "queued" | "failed" | "unknown";
export type OfflineDeliveryPolicy = "mailbox" | "reject";

/** Broker roster classification for a connected endpoint. */
export type SessionKind = "agent" | "human" | "service";

export interface DeliveryDetails {
  delivery: DeliveryState;
  code?: string;
  retryable: boolean;
  outcomeKnown: boolean;
}

export type HerdrLocation =
  | {
      status: "current";
      workspace: { id: string; label: string };
      tab: { id: string; label: string };
      paneId: string;
      /** Time when the broker requested the live Herdr snapshot. */
      refreshedAt: number;
    }
  | { status: "not_hosted" }
  | {
      status: "unavailable";
      paneId: string;
      reason: "herdr_unavailable" | "unsupported" | "command_failed" | "pane_missing" | "invalid_response";
      detail?: string;
    };

export interface SessionInfo {
  id: string;
  /** Broker-owned lifetime of this live endpoint. */
  endpointEpoch?: string;
  /** Explicit or broker-classified endpoint kind. Older brokers may omit it. */
  kind?: SessionKind;
  /** True while this endpoint is present in the live broker roster. */
  ready?: boolean;
  name?: string;
  /** True only when the extension synthesized name for an unnamed runtime. */
  runtimeFallbackAlias?: boolean;
  cwd: string;
  /** Agent model identity. Human and service endpoints need not invent one. */
  model?: string;
  pid: number;
  startedAt: number;
  lastActivity: number;
  status?: string;
  peerUid?: number;
  trustedLocal?: boolean;
  /** Live context-window usage, pushed via presence from the source session's
   *  getContextUsage(). contextPct is 0..100 (rounded); contextTokens /
   *  contextWindow are raw token counts. All optional: unknown right after a
   *  compaction (before the next assistant response), when no model is selected,
   *  or on older clients that never report it. */
  contextPct?: number;
  contextTokens?: number;
  contextWindow?: number;
  /** tmux pane id (e.g. "%212") of the session's terminal, read from
   *  $TMUX_PANE at registration. Present only when the session runs inside a
   *  tmux pane; absent for cloud, headless, IDE-embedded, or Herdr sessions.
   *  The pane id is immutable for the process lifetime — unlike the window
   *  name, which is mutable — so a peer can live-resolve the current window
   *  from it via tmux when it needs to introspect or drive that pane. */
  tmuxPane?: string;
  /** Launch-time Herdr pane alias. It may differ from the current pane id after a move. */
  herdrPaneId?: string;
  /** Present on list responses. `current` is freshly resolved for that request;
   *  other states explicitly distinguish non-Herdr sessions from failures. */
  herdrLocation?: HerdrLocation;
}

export type SessionHolder = Pick<SessionInfo, "pid" | "cwd" | "name">;

export interface CrossMachineOrigin {
  name: string;
  sessionId: string;
  machine: string;
}

export interface CrossMachineProvenance {
  type: "ssh-relay";
  version: 1;
  origin: CrossMachineOrigin;
  trust: "ssh-asserted";
}

export interface Message {
  id: string;
  timestamp: number;
  senderSequence?: number;
  brokerReceivedAt?: number;
  brokerDeliveredAt?: number;
  receiverReceivedAt?: number;
  injectedAt?: number;
  supersedes?: string;
  retryOf?: string;
  replyTo?: string;
  expectsReply?: boolean;
  provenance?: MessageProvenance;
  crossMachine?: CrossMachineProvenance;
  content: {
    text: string;
    attachments?: Attachment[];
  };
}

export interface MessageProvenance {
  type: "extension_outbox";
  extensionId: string;
  extensionName: string;
  requestId: string;
}

export interface Attachment {
  type: "file" | "snippet" | "context";
  name: string;
  content: string;
  language?: string;
}

export type MessageReceiptStatus = "receiver_received" | "queued" | "injected" | "acknowledged" | "expired" | "cancelled" | "superseded" | "cancellation_requested";

export interface MessageReceipt {
  messageId: string;
  status: MessageReceiptStatus;
  timestamp: number;
  detail?: string;
}

export type MessageControlAction = "cancel" | "supersede";

export interface MessageControl {
  messageId: string;
  action: MessageControlAction;
  timestamp: number;
  supersededBy?: string;
  detail?: string;
}

export interface ExtensionCapability {
  namespace: string;
  ownerEligible: boolean;
}

export type SessionRegistration = Omit<SessionInfo, "id" | "endpointEpoch" | "ready" | "peerUid" | "trustedLocal" | "herdrLocation"> & {
  extensions?: ExtensionCapability[];
  /** Broker-only join hint; never returned in the public roster. */
  herdrSessionPath?: string;
  /** The client sends `receiver_received` for every message it is handed, so the broker may wait for it before reporting delivery. */
  acknowledgesReceipts?: boolean;
  /** The client sends a frame at least this often, so the broker may drop it after several silent intervals. */
  livenessIntervalMs?: number;
  /** What the broker should do with ordinary sends after this endpoint disconnects. Defaults to `mailbox`. `reject` also requires `acknowledgesReceipts: true`. */
  offlineDelivery?: OfflineDeliveryPolicy;
};

/**
 * Classify legacy registrations without forcing existing Pi clients to add a
 * new field. Explicit kinds win; a model identifies an agent; operator
 * evidence identifies a service. Unknown endpoints default to service so they
 * are never presented as people or Pi agents by accident.
 */
export function classifySessionKind(
  session: Pick<SessionRegistration, "kind" | "model" | "status">,
): SessionKind {
  if (session.kind) return session.kind;
  if (session.status === "operator" || session.model === "qm-ssh" || session.model === "operator") return "service";
  if (session.model?.trim()) return "agent";
  return "service";
}

export type ClientMessage =
  | { type: "register"; session: SessionRegistration; sessionId?: string; stateId?: string; scopeId?: string }
  | { type: "unregister" }
  | { type: "extension_capabilities_update"; extensions: ExtensionCapability[] }
  | { type: "list"; requestId: string }
  | { type: "send"; to: string; message: Message; targetId?: string; targetEpoch?: string }
  | { type: "message_receipt"; receipt: MessageReceipt }
  | { type: "cancel_message"; messageId: string }
  | { type: "cancel_ask"; messageId: string }
  | { type: "presence"; name?: string; runtimeFallbackAlias?: boolean; status?: string; model?: string; contextPct?: number | null; contextTokens?: number | null; contextWindow?: number | null }
  | {
      type: "extension_publish";
      namespace: string;
      audience: "owner" | "capable";
      ownerEpoch?: string;
      ownerOnly?: boolean;
      payload: unknown;
    }
  | {
      type: "extension_state_commit";
      namespace: string;
      ownerEpoch: string;
      expectedRevision: number;
      payload: unknown;
    };

export type BrokerMessage =
  | { type: "registered"; sessionId: string; features?: string[] }
  | { type: "sessions"; requestId: string; sessions: SessionInfo[] }
  | { type: "message"; from: SessionInfo; message: Message }
  | { type: "presence_update"; session: SessionInfo }
  | { type: "session_joined"; session: SessionInfo }
  | { type: "session_left"; sessionId: string }
  | { type: "error"; error: string; code?: string; holder?: SessionHolder }
  | ({ type: "delivered"; messageId: string } & DeliveryDetails)
  | ({ type: "delivery_failed"; messageId: string; reason: string } & DeliveryDetails)
  | { type: "message_receipt"; from: SessionInfo; receipt: MessageReceipt }
  | { type: "message_control"; from: SessionInfo; control: MessageControl }
  | { type: "extension_owner"; namespace: string; ownerId?: string; ownerEpoch?: string }
  | {
      type: "extension_message";
      namespace: string;
      fromSessionId: string;
      ownerId?: string;
      ownerEpoch?: string;
      payload: unknown;
    }
  | {
      type: "extension_state";
      namespace: string;
      revision: number;
      payload: unknown;
    }
  | {
      type: "extension_state_result";
      namespace: string;
      committed: boolean;
      revision: number;
      reason?: string;
    };
