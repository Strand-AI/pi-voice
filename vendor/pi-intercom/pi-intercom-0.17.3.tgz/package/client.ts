import { randomUUID } from "node:crypto";
import { EventEmitter } from "node:events";
import { IntercomClient } from "./broker/client.ts";
import { spawnBrokerIfNeeded } from "./broker/spawn.ts";
import { loadConfig } from "./config.ts";
import { classifySessionKind, EXACT_SEND_FEATURE, OFFLINE_DELIVERY_REJECT_FEATURE } from "./types.ts";
import type {
  Message,
  OfflineDeliveryPolicy,
  SessionInfo,
  SessionKind,
  SessionRegistration,
} from "./types.ts";
import type {
  ConnectOptions,
  ExactSessionTarget,
  SendOptions,
  SendResult,
} from "./broker/client.ts";

export { IntercomClient } from "./broker/client.ts";
export type { ConnectOptions, ExactSessionTarget, SendOptions, SendResult } from "./broker/client.ts";
export { loadConfig } from "./config.ts";
export type { IntercomConfig } from "./config.ts";
export { spawnBrokerIfNeeded } from "./broker/spawn.ts";
export {
  getAgentDirPath,
  getBrokerConnectTarget,
  getBrokerSocketPath,
  getIntercomDirPath,
} from "./broker/paths.ts";
export { classifySessionKind, EXACT_SEND_FEATURE, OFFLINE_DELIVERY_REJECT_FEATURE } from "./types.ts";
export type {
  Attachment,
  DeliveryDetails,
  DeliveryState,
  Message,
  OfflineDeliveryPolicy,
  SessionInfo,
  SessionKind,
  SessionRegistration,
} from "./types.ts";

/** Start the configured broker only when no compatible broker is already live. */
export async function ensureIntercomBroker(): Promise<void> {
  const config = loadConfig();
  if (!config.enabled) throw new Error("pi-intercom is disabled in config.json");
  await spawnBrokerIfNeeded(config.brokerCommand, config.brokerArgs);
}

export interface NativeEndpointOptions {
  /** Stable broker identity. Use the same value after reconnecting. */
  id: string;
  name: string;
  kind: SessionKind;
  cwd: string;
  status?: string;
  pid?: number;
  scopeId?: string;
  /** Reject ordinary offline delivery instead of retaining broker mailbox messages. */
  offlineDelivery?: OfflineDeliveryPolicy;
}

/**
 * Supported long-lived client facade for non-Pi endpoints.
 *
 * It preserves the broker's ordinary addressed-message protocol while making
 * strict id+epoch delivery the only send operation exposed by this facade.
 * The empty model field is a wire-compatibility value required by legacy
 * brokers (including 0.16); it is never presented as an endpoint model.
 */
export const NATIVE_UNKNOWN_MESSAGE_CAPACITY = 4_096;

export class NativeIntercomClient extends EventEmitter {
  private readonly client = new IntercomClient();
  private readonly options: NativeEndpointOptions;
  private readonly startedAt = Date.now();
  private ownEndpointEpoch: string | null = null;
  private connectionGeneration = 0;
  private readonly unknownMessageIds = new Set<string>();
  private unknownLedgerExhausted = false;

  constructor(options: NativeEndpointOptions) {
    super();
    if (!options.id.trim()) throw new Error("Native endpoint id must not be empty");
    if (!options.name.trim()) throw new Error("Native endpoint name must not be empty");
    this.options = { ...options, id: options.id.trim(), name: options.name.trim() };

    // IntercomClient uses EventEmitter's special "error" event. Always attach
    // a listener so a transient socket failure cannot terminate a native host.
    this.client.on("error", (error) => this.emit("client_error", error));
    this.client.onMessage((from, message) => {
      if (this.options.offlineDelivery === "reject") {
        const generation = this.connectionGeneration;
        const ownSessionId = this.client.sessionId;
        const ownEndpointEpoch = this.ownEndpointEpoch;
        const exactFeature = this.client.supportsFeature(EXACT_SEND_FEATURE);
        const rejectFeature = this.client.supportsFeature(OFFLINE_DELIVERY_REJECT_FEATURE);
        try {
          if (
            ownSessionId === null
            || ownEndpointEpoch === null
            || !exactFeature
            || !rejectFeature
            || !this.client.isConnected()
          ) {
            throw new Error("Inbound message arrived before native connection authority was verified");
          }
          const accepted = this.client.sendMessageReceipt({ messageId: message.id, status: "receiver_received", timestamp: Date.now() });
          if (
            !accepted
            || generation !== this.connectionGeneration
            || ownSessionId !== this.client.sessionId
            || ownEndpointEpoch !== this.ownEndpointEpoch
            || exactFeature !== this.client.supportsFeature(EXACT_SEND_FEATURE)
            || rejectFeature !== this.client.supportsFeature(OFFLINE_DELIVERY_REJECT_FEATURE)
            || !this.client.isConnected()
          ) {
            throw new Error("Inbound receipt was not accepted on the verified native connection");
          }
        } catch (error) {
          this.emit("client_error", error);
          void this.client.disconnect().catch(() => undefined);
          return;
        }
      }
      this.emit("message", this.normalizeSession(from), message);
    });
    this.client.onSessionJoined(() => { void this.refreshRoster().catch((error) => this.emit("roster_error", error)); });
    this.client.onSessionLeft(() => { void this.refreshRoster().catch((error) => this.emit("roster_error", error)); });
    this.client.onPresenceUpdate(() => { void this.refreshRoster().catch((error) => this.emit("roster_error", error)); });
    this.client.onDisconnected(() => {
      this.connectionGeneration++;
      this.ownEndpointEpoch = null;
      this.emit("roster", []);
      this.emit("disconnected");
    });
  }

  get sessionId(): string | null {
    return this.client.sessionId;
  }

  get endpointEpoch(): string | null {
    return this.ownEndpointEpoch;
  }

  get connected(): boolean {
    return this.client.isConnected() && this.ownEndpointEpoch !== null;
  }

  isConnected(): boolean {
    return this.connected;
  }

  async connect(options: { startBroker?: boolean } = {}): Promise<void> {
    if (options.startBroker !== false) await ensureIntercomBroker();
    const generation = ++this.connectionGeneration;
    const now = Date.now();
    const registration: SessionRegistration = {
      name: this.options.name,
      kind: this.options.kind,
      cwd: this.options.cwd,
      // Required on the wire by released brokers through 0.16. Empty means
      // "not an agent model" and avoids impersonating a Pi/model endpoint.
      model: "",
      pid: this.options.pid ?? process.pid,
      startedAt: this.startedAt,
      lastActivity: now,
      status: this.options.status ?? this.options.kind,
      ...(this.options.offlineDelivery === undefined ? {} : { offlineDelivery: this.options.offlineDelivery }),
      ...(this.options.offlineDelivery === "reject" ? { acknowledgesReceipts: true } : {}),
    };
    const connectOptions: ConnectOptions = this.options.scopeId === undefined
      ? {}
      : { scopeId: this.options.scopeId };
    await this.client.connect(registration, this.options.id, connectOptions);
    const requiredFeatures = [EXACT_SEND_FEATURE, ...(this.options.offlineDelivery === "reject" ? [OFFLINE_DELIVERY_REJECT_FEATURE] : [])];
    const missingFeature = requiredFeatures.find((feature) => !this.client.supportsFeature(feature));
    if (missingFeature) {
      await this.client.disconnect();
      throw new Error(`Connected broker does not support ${missingFeature}`);
    }
    const sessions = await this.refreshRoster(generation, false);
    const own = sessions.find((session) => session.id === this.options.id);
    if (generation !== this.connectionGeneration || !this.client.isConnected() || !own?.endpointEpoch) {
      await this.client.disconnect();
      throw new Error("Native endpoint identity is missing or stale in the broker roster");
    }
    this.ownEndpointEpoch = own.endpointEpoch;
    this.emit("roster", sessions);
    this.emit("connected");
  }

  async disconnect(): Promise<void> {
    const wasConnected = this.connected;
    this.connectionGeneration++;
    this.ownEndpointEpoch = null;
    await this.client.disconnect();
    if (wasConnected) {
      this.emit("roster", []);
      this.emit("disconnected");
    }
  }

  async listSessions(options?: { timeoutMs?: number }): Promise<SessionInfo[]> {
    const generation = this.connectionGeneration;
    const sessions = await this.client.listSessions(options);
    if (generation !== this.connectionGeneration || !this.client.isConnected()) {
      throw new Error("Discarded stale roster response from an earlier connection generation");
    }
    return sessions.map((session) => this.normalizeSession(session));
  }

  async sendExact(target: ExactSessionTarget, options: SendOptions): Promise<SendResult> {
    const generation = this.connectionGeneration;
    const ownSessionId = this.client.sessionId;
    const ownEndpointEpoch = this.ownEndpointEpoch;
    const exactFeature = this.client.supportsFeature(EXACT_SEND_FEATURE);
    const rejectFeature = this.client.supportsFeature(OFFLINE_DELIVERY_REJECT_FEATURE);
    if (!this.connected || ownSessionId === null || ownEndpointEpoch === null) throw new Error("Native endpoint identity is not connected and verified");
    if (!exactFeature) throw new Error(`Connected broker does not support ${EXACT_SEND_FEATURE}`);
    if (this.options.offlineDelivery === "reject" && !rejectFeature) {
      throw new Error(`Connected broker does not support ${OFFLINE_DELIVERY_REJECT_FEATURE}`);
    }
    if (this.unknownLedgerExhausted) throw new Error("Native unknown-delivery ledger is exhausted; restart recovery is required");

    // Materialize caller-controlled values before the final authority check. The
    // underlying client then receives plain objects and captures its active socket
    // synchronously, so a stale generation cannot redirect this body to another
    // connection.
    const exactTarget: ExactSessionTarget = { id: target.id, endpointEpoch: target.endpointEpoch };
    const messageId = options.messageId ?? randomUUID();
    const sendOptions: SendOptions = {
      text: options.text,
      ...(options.attachments === undefined ? {} : { attachments: options.attachments }),
      ...(options.replyTo === undefined ? {} : { replyTo: options.replyTo }),
      ...(options.expectsReply === undefined ? {} : { expectsReply: options.expectsReply }),
      messageId,
      ...(options.supersedes === undefined ? {} : { supersedes: options.supersedes }),
      ...(options.retryOf === undefined ? {} : { retryOf: options.retryOf }),
      ...(options.provenance === undefined ? {} : { provenance: options.provenance }),
      ...(options.crossMachine === undefined ? {} : { crossMachine: options.crossMachine }),
    };
    if (
      generation !== this.connectionGeneration
      || ownSessionId !== this.client.sessionId
      || ownEndpointEpoch !== this.ownEndpointEpoch
      || !this.client.isConnected()
      || exactFeature !== this.client.supportsFeature(EXACT_SEND_FEATURE)
      || rejectFeature !== this.client.supportsFeature(OFFLINE_DELIVERY_REJECT_FEATURE)
    ) {
      throw new Error("Native endpoint connection authority changed before send");
    }
    if (this.unknownMessageIds.has(messageId)) throw new Error(`Message id ${messageId} has an unknown prior delivery and cannot be replayed`);
    try {
      const result = await this.client.sendExact(exactTarget, sendOptions);
      if (result.delivery === "unknown" || !result.outcomeKnown) this.rememberUnknown(messageId);
      return result;
    } catch (error) {
      this.rememberUnknown(messageId);
      throw error;
    }
  }

  onMessage(handler: (from: SessionInfo, message: Message) => void): () => void {
    this.on("message", handler);
    return () => this.off("message", handler);
  }

  onSessionJoined(handler: (session: SessionInfo) => void): () => void {
    return this.client.onSessionJoined((session) => handler(this.normalizeSession(session)));
  }

  onSessionLeft(handler: (sessionId: string) => void): () => void {
    return this.client.onSessionLeft(handler);
  }

  onPresenceUpdate(handler: (session: SessionInfo) => void): () => void {
    return this.client.onPresenceUpdate((session) => handler(this.normalizeSession(session)));
  }

  onDisconnected(handler: (error?: Error) => void): () => void {
    this.on("disconnected", handler);
    return () => this.off("disconnected", handler);
  }

  private rememberUnknown(messageId: string): void {
    if (this.unknownMessageIds.has(messageId) || this.unknownLedgerExhausted) return;
    if (this.unknownMessageIds.size >= NATIVE_UNKNOWN_MESSAGE_CAPACITY) {
      this.unknownLedgerExhausted = true;
      return;
    }
    this.unknownMessageIds.add(messageId);
    if (this.unknownMessageIds.size >= NATIVE_UNKNOWN_MESSAGE_CAPACITY) this.unknownLedgerExhausted = true;
  }

  private async refreshRoster(generation = this.connectionGeneration, publish = true): Promise<SessionInfo[]> {
    const sessions = await this.listSessions();
    if (generation !== this.connectionGeneration || !this.client.isConnected()) {
      throw new Error("Discarded stale roster response from an earlier connection generation");
    }
    if (publish) this.emit("roster", sessions);
    return sessions;
  }

  private normalizeSession(session: SessionInfo): SessionInfo {
    const ownEndpoint = session.id === this.options.id;
    const kind = ownEndpoint ? this.options.kind : classifySessionKind(session);
    const { model, ...withoutModel } = session;
    return {
      ...withoutModel,
      kind,
      ready: true,
      // Hide the legacy empty compatibility field from native consumers.
      ...(model ? { model } : {}),
    };
  }
}
